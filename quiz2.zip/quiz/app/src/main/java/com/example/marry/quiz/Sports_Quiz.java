package com.example.marry.quiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

/**
 * Created by Mary on 03/28/2018.
 */

public class Sports_Quiz extends Activity{

    int total=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sports_quiz);
    }

    private int checkAnswers(){
        /*
          gaseste raspunsul corect de la intrebarea 1 si daca este bifata casuta corecta o aduna la total
         */
        RadioButton q1RadioButton = findViewById(R.id.answer_three_question_one_sports_quiz);
        Boolean q1 = q1RadioButton.isChecked();

        if (q1){
            total++;
        }

        /*
          gaseste raspunsul de la intrebarea 2 si daca este corect il aduna la total
         */
        EditText q2EditText = findViewById(R.id.answer_question_two_sports_quiz);
        String q2  =  q2EditText.getText().toString();

        if(q2.equals("34") || q2.equals("Thirty Four")){
            total++;
        }

        /*
          gaseste raspunsul corect de la intrebarea 3 si daca sunt bifate casutele corecte o aduna la total
         */
        CheckBox q3aRadioButton = findViewById(R.id.answer_one_question_three_sports_quiz);
        Boolean q3a = q3aRadioButton.isChecked();

        CheckBox q3bRadioButton = findViewById(R.id.answer_two_question_three_sports_quiz);
        Boolean q3b = q3bRadioButton.isChecked();

        if (q3a && q3b){
            total++;
        }

        /*
          gaseste raspunsul corect de la intrebarea 6 si daca este bifata casuta corecta o aduna la total
         */
        RadioButton q4RadioButton = findViewById(R.id.answer_one_question_four_sports_quiz);
        Boolean q4 = q4RadioButton.isChecked();

        if (q4){
            total++;
        }
        return total;
    }

    /**
     * it opens the pop up to see the results
     */
    public void seeAnswerSportsQuiz(View v) {
        Button b = findViewById(R.id.sports_button);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Sports_Quiz.this, Pop_Sports.class));
            }
        });

        /*
            passes the data to the view I need: pop fashion
         */
        Intent passDataSportsQuiz = new Intent(Sports_Quiz.this, Pop_Sports.class);
        passDataSportsQuiz.putExtra("answer", checkAnswers());
        startActivity(passDataSportsQuiz);
    }
}