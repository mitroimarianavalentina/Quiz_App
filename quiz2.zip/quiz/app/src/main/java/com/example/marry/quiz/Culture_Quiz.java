package com.example.marry.quiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

/**
 * Created by Mary on 03/28/2018.
 */

public class Culture_Quiz extends Activity {

    int total = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.culture_quiz);
    }

    private int checkAnswers() {
        /*
          finds the answer for question 1 and if it's the right one adds it to total
         */
        EditText q1EditText = findViewById(R.id.answer_question_one_culture_quiz);
        String q1 = q1EditText.getText().toString();

        if (q1.equals("Bucharest")) {
            total++;
        }


        /*
          finds the answer for question 2 and if it's the right one adds it to total
         */
        RadioButton q2RadioButton = findViewById(R.id.answer_two_question_two_culture_quiz);
        Boolean q2 = q2RadioButton.isChecked();

        if (q2) {
            total++;
        }

        /*
          finds the answer for question 3 and if it's the right one adds it to total
         */
        CheckBox q3aRadioButton = findViewById(R.id.answer_one_question_three_culture_quiz);
        Boolean q3a = q3aRadioButton.isChecked();

        CheckBox q3bRadioButton = findViewById(R.id.answer_two_question_three_culture_quiz);
        Boolean q3b = q3bRadioButton.isChecked();

        CheckBox q3cRadioButton = findViewById(R.id.answer_three_question_three_culture_quiz);
        Boolean q3c = q3cRadioButton.isChecked();

        if (q3a && q3b && q3c) {
            total++;
        }
        return  total;
    }

    /**
     * it opens the pop up to see the results
     */
    public void seeAnswerSportsQuiz(View v) {
        Button b = findViewById(R.id.culture_button);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Culture_Quiz.this, Pop_Culture.class));
            }
        });

        /*
            passes the data to the view I need: pop fashion
         */
        Intent passDataCultureQuiz = new Intent(Culture_Quiz.this, Pop_Culture.class);
        passDataCultureQuiz.putExtra("answer", checkAnswers());
        startActivity(passDataCultureQuiz);
    }
}