package com.example.marry.quiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

/**
 * Created by Mary on 03/28/2018.
 */

public class Fashion_Quiz extends Activity {

    int total = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fashion_quiz);

    }

    private int checkAnswers() {
        /*
          finds the answer for question 1 and if it's the right one adds it to total
         */
        RadioButton q1RadioButton = findViewById(R.id.answer_one_question_one_fashion_quiz);
        Boolean q1 = q1RadioButton.isChecked();

        if (q1) {
            total++;
        }


        /*
          finds the answer for question 2 and if it's the right one adds it to total
         */
        EditText q2EditText = findViewById(R.id.answer_question_two_fashion_quiz);
        String q2 = q2EditText.getText().toString();

        if (q2.equals("Handbags") || q2.equals("Handbag") || q2.equals("Purse") || q2.equals("Purses")) {
            total++;
        }

        /*
          finds the answer for question 3 and if it's the right one adds it to total
         */
        RadioButton q3RadioButton = findViewById(R.id.answer_one_question_three_fashion_quiz);
        Boolean q3 = q3RadioButton.isChecked();

        if (q3) {
            total++;
        }
        return total;
    }

    /**
     * it opens the pop up to see the results
     */
    public void seeAnswerFashionQuiz(View v) {
        Button b = findViewById(R.id.fashion_button);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Fashion_Quiz.this, Pop_Fashion.class));
            }
        });

        /*
            passes the data to the view I need: pop fashion
         */
        Intent passDataFashionQuiz = new Intent(this, Pop_Fashion.class);
        passDataFashionQuiz.putExtra("answer", checkAnswers());
        startActivity(passDataFashionQuiz);
    }
}